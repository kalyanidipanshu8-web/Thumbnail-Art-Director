# Typography Guide

Type on a thumbnail must read at phone size, roughly 160 to 200 pixels wide in a feed. Design every text element for that size first.

## Font categories

Describe typefaces by category and traits. Do not name an exact font unless you have clear evidence.

| Category | Traits | Thumbnail use |
|---|---|---|
| Heavy condensed grotesque | Tall, narrow, very heavy strokes | Main keyword, "MASTER" style headlines |
| Heavy geometric sans | Round forms, even weight, wide | Short punchy words, numbers, badges |
| High-contrast serif display | Thick and thin strokes, sharp serifs | Editorial headlines, single large words |
| Brush or handwritten | Organic, informal | Callouts beside arrows, "how I did it" notes |
| Rounded sans | Soft terminals, friendly | Brand-style lockups, light tutorial tone |

## Font weight

- Use heavy or black weight for the main headline. Thin weights disappear at small sizes.
- Use one weight step lighter for secondary text. Two heavy weights side by side compete.
- Avoid more than two weights in one thumbnail.

## Letter spacing

- Tight tracking (slightly negative) suits condensed display headlines and keeps the block compact.
- Open tracking suits small secondary labels in all caps.
- Do not let words in one headline touch or overlap unless the overlap is a deliberate design device.

## Text alignment

- Left-aligned headlines suit a subject on the right. Right-aligned suits a subject on the left.
- Centred text works only for short single-word or number headlines.
- Keep margins of at least five percent of the frame width from every edge.

## Size relative to the frame

- Main headline: occupies roughly a third to half of the frame height.
- Secondary text: about a third of the headline size.
- Badges and labels: small, but never smaller than the readable minimum at phone size.
- Use no more than three text sizes.

## Stroke, outline, and shadow

- A dark outline or thick drop shadow keeps light text legible over busy images. Outline width of about 3 to 6 percent of the cap height is typical.
- A solid colour box behind text (red, white, or black) is an alternative to outline. It works well for banner presenter styles.
- Avoid glows and soft shadows as the only legibility device on busy backgrounds.

## Text colour combinations

| Text | Background | Use |
|---|---|---|
| White | Near-black | Default tutorial overlay |
| Yellow | Dark or photo | One-word emphasis |
| White on red | Red band | Creator-series banner |
| Black | Off-white | Editorial display |
| Yellow on black outline | Busy photo | Keyword over subject |

## Placement and readability

- Place text in the area that the subject does not occupy, usually the opposite third.
- Keep text away from the bottom-right corner where video duration badges appear on the platform.
- Keep text away from the faces of the subject.
- Limit the headline to two to four words. Longer phrases shrink until they are unreadable.
- Check at thumbnail size before finishing.

## Text effects used in the references

- Hand-drawn curved arrows pointing from text to subject.
- Solid colour rectangles behind short phrases.
- Oversized words that overlap the subject's silhouette slightly, creating depth.
- Single-word emphasis, with one word in a different colour from the rest.

## Text in generated images

Image models often misspell text or render it unevenly. Generate the image without text whenever possible, then add headline text in an editor using the rules above. If you do request text in the prompt, keep it to one or two words in quotation marks and expect to regenerate.
