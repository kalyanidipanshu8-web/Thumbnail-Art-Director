# Colour Theory for Thumbnails

All hex values are estimates from visual inspection of compressed reference images. Treat them as starting points and check them against your own render.

## Core relationships

| Relationship | What it does | Thumbnail use |
|---|---|---|
| Complementary (red vs green, orange vs blue) | Maximum contrast between two hues | Subject in warm tone against a cool background |
| Analogous (neighbouring hues) | Calm and cohesive | Cinematic grades with teal and blue-green |
| Monochrome plus one accent | One colour dominates and one draws the eye | Black and white base with a yellow or red keyword |
| Split complementary | High contrast with less tension than a pure pair | Warm subject, blue-violet background, yellow text |

## Warm versus cool balance

- Warm elements (red, orange, yellow) advance toward the viewer. Put the subject or the key text here.
- Cool elements (blue, teal, grey) recede. Put the background here.
- The references mostly use a warm accent on a cool or dark base, which gives separation without extra effects.

## Contrast

- The most important contrast in a thumbnail is value (light against dark), not hue. Check the thumbnail in greyscale. If the subject and the text blur together, the value contrast is too low.
- Keep the text at a strong value contrast with its background. White on near-black and black on off-white are reliable. Yellow on dark is also strong.
- Avoid placing mid-tone text on a mid-tone background.

## Saturation

- Use one fully saturated colour as the accent. Keep the rest desaturated or near-neutral.
- Several saturated colours at once compete for attention and weaken the hierarchy.

## Background-to-subject separation

Three reliable methods:
1. **Value separation:** a bright subject on a dark background, or the reverse.
2. **Hue separation:** a warm subject against a cool background.
3. **Edge separation:** a rim light or thin outline along the subject's silhouette.

## Colour psychology (design reasoning only)

Describe colour by its visual role, not by claimed viewer reactions.

- **Red** reads as urgent and high energy. It works as a banner, a badge, or a keyword highlight.
- **Yellow** is the most visible colour on dark backgrounds. It is well suited to one-word emphasis.
- **Black and charcoal** provide a stable base and make accents pop.
- **Cool blue and teal** create a calm or cinematic mood, and they recede well behind a subject.
- **Off-white and cream** give an editorial, clean look when paired with black type.

## Palettes from the references (estimated)

**Tutorial overlay:** near-black `#111111`, white `#FFFFFF`, yellow accent `#FFD21F`, optional red `#D7141A`.

**Creator-series banner:** red `#D7141A`, white `#FFFFFF`, charcoal `#1B1B1B`, yellow `#FFD21F`.

**Cinematic photoreal:** deep teal `#0E3B43`, warm skin highlight `#E8B48A`, shadow navy `#0B1A2A`, amber rim `#F2A43A`.

**Editorial display:** off-white `#F4EFE6`, black `#0A0A0A`, accent red `#D0312D`.

**Illustrative 3D:** sky blue `#8FD3F4`, burnt orange `#E8562A`, cream `#FFF6E9`, deep blue `#1E3A5F`.

**Character macro:** slate `#2B3440`, ember orange `#E0703A`, pale gold `#E9C46A`, petal pink `#E7A3B5`.

## Practical rules for a new thumbnail

1. Choose one dominant colour family for the background.
2. Choose one accent colour and use it for the keyword only.
3. Put the subject in a warm or bright tone when the background is cool or dark.
4. Check greyscale: subject and text must still separate by value.
5. Keep total distinct colours to four or fewer, not counting skin tones and small details.
