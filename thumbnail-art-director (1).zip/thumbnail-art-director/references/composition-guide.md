# Composition Guide

## Layout systems

**Rule of thirds.** Place the subject's eyes or the key object on a third line. This is the default for most references, with the subject offset to the right or left and text in the opposite third.

**Centred hero.** A single subject in the middle with text above or below. Works for the editorial display style and for very short headlines.

**Split panel.** Two equal halves separated by a hard line. Used for before and after, and for comparisons.

**Grid of three.** Three panels or three subjects in a row. Used for series or numbered content.

**Layered depth.** Foreground (subject or large text), midground (secondary objects), background (environment). Keeps the frame from looking flat.

## Visual hierarchy

Order the elements by how fast the eye should reach them:

1. **Subject face or key object.** Most viewers look at faces first.
2. **Headline text.** Short, large, high contrast.
3. **Accent annotation** such as an arrow, badge, or logo.
4. **Background detail.** Supports the subject without competing.

Test the hierarchy by squinting or by viewing the thumbnail at 10 percent size. The subject and the headline should still be the first two things you see.

## Subject placement

- Place the face in the upper half of the frame. Leave headroom of about a tenth of the frame height above the top of the head.
- Keep the face clear of the text and the bottom-right corner.
- For presenter styles, place the subject in the right third with eyes near the upper third line.
- For action styles, place the subject slightly off centre and let the action point toward the open space.

## Negative space

- Leave one clear area of negative space for the headline. Usually this is the side opposite the subject.
- Negative space should be quiet: a gradient, a plain wall, a soft blur. Busy space behind text reduces legibility.
- Too little negative space makes the thumbnail feel crowded. Too much makes the subject feel small. Aim for the subject taking roughly 40 to 60 percent of the frame.

## Attention direction

- **Gaze.** A subject looking toward the headline or the open space pulls the eye that way. A subject looking out of frame pushes the eye away, so avoid it when the headline is on the same side.
- **Arrows.** A curved arrow points from text to subject or from subject to result. Keep the arrow tail near the text and the head on the target.
- **Gesture.** A raised hand, pointing finger, or open palm directs attention and can frame the headline.
- **Lines.** Diagonal lines (a road, a shoulder, a sword) lead the eye into the subject.

## Depth and perspective

- A low camera angle makes a subject look heroic. A high angle makes it look small or vulnerable.
- Shallow depth of field isolates the subject from the background. Keep the subject sharp and the background soft.
- A medium close-up is the most common subject framing across the references. Full-body shots work for scale or a reveal.

## Aspect ratio

- Default to 16:9 for long-form video thumbnails.
- For Shorts or Reels, a vertical 9:16 frame needs a different layout. Keep text and faces in the central safe zone, away from the top and bottom interface bars.

## Composition checklist

- [ ] Subject occupies 40 to 60 percent of the frame.
- [ ] Face sits in the upper half and clears the text.
- [ ] Headline sits in negative space on the opposite side.
- [ ] One clear hierarchy: subject, headline, accent.
- [ ] Gaze or gesture points toward the headline or the result.
- [ ] Bottom-right corner is free of key content.
- [ ] Readable at 10 percent size.
