# Prompt Engineering Guide

## Method

A good thumbnail prompt is a complete visual brief written in plain, specific language. Build it from the 11 slots below, in order. Keep each slot to one or two sentences. Put the most important visual information first, because image models weight early words more heavily.

## The 11 slots

1. **Main subject:** who or what, generically described.
2. **Subject appearance and positioning:** age range, hair, clothing, expression, pose, and where in the frame.
3. **Background:** environment, colour, and how it is blurred or lit.
4. **Composition:** layout (rule of thirds, split panel, centred hero) and empty space for text.
5. **Colour palette:** base, accent, and the rule for each.
6. **Lighting:** key light direction, rim light, shadow quality.
7. **Typography instructions:** headline words and placement, or "no text" with a note to add text later.
8. **Visual effects:** particles, glow, motion blur, depth of field, arrows.
9. **Camera perspective:** angle, lens feel, framing (close-up, medium, wide).
10. **Rendering quality:** photoreal, 3D render, illustrated, with detail level.
11. **Aspect ratio:** 16:9 unless stated otherwise.

Add a **negative prompt** when the model tends to produce a known problem (extra fingers, garbled text, watermarks, cluttered background).

## Template

```
[Main subject], [appearance and expression], [pose and position in frame].
Background: [environment, colour, blur level].
Composition: [layout], subject on the [left/right] third, clear negative space on the [opposite side] for headline text.
Colour palette: [base colour] background, [accent colour] accent used only on [element], [neutral] midtones.
Lighting: [key light direction and quality], [rim light], [shadow depth].
Effects: [particles / glow / depth of field / none].
Camera: [angle], [lens feel], [framing].
Rendering: [photoreal / stylised 3D / illustrated], highly detailed, sharp focus on subject.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```

Text is added afterwards in an editor, following the typography guide.

## Good prompts (original topics)

### 1. Bold Overlay Tutorial: "Build a Budget Tracker in One Afternoon"
```
A young woman in her twenties with a focused, slightly surprised expression, shoulder-length dark hair, plain grey hoodie, sitting at a desk and leaning toward a laptop, positioned on the right third of the frame, eyes near the upper third line.
Background: dim home office, warm desk lamp blurred into soft bokeh on the left, clear dark negative space on the left for headline text.
Composition: medium close-up, subject right, 16:9.
Colour palette: near-black background, warm amber lamp light, white highlights, one small yellow accent on the laptop screen glow.
Lighting: warm key from the lamp, cool soft fill from the screen, subtle rim light on the hair.
Effects: none beyond light falloff.
Camera: slightly low eye-level, 85mm feel, shallow depth of field.
Rendering: photoreal, highly detailed skin texture, sharp focus on the face.
No text, no logos, no watermarks.
```
Add later: "BUDGET IN 1 DAY" in heavy condensed white caps on the left, with a yellow curved arrow pointing at the laptop.

### 2. Split-Screen Comparison: "Before and After My Garden Makeover"
```
Two side-by-side panels, hard vertical divider in the centre. Left panel: a neglected backyard with brown grass and a cracked patio. Right panel: the same backyard, lush green lawn, potted plants, and a wooden bench. Same camera angle and framing in both.
Lighting: overcast daylight in the left panel, warm golden hour in the right.
Colour palette: desaturated greys and browns on the left, saturated greens and warm gold on the right.
Composition: 50/50 split, clear space at the bottom of each panel for a label.
Camera: wide, eye level, identical in both panels.
Rendering: photoreal, sharp focus across both panels.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```
Add later: "DAY 1" and "DAY 30" label blocks in white on red, bottom-left of each panel.

### 3. Cinematic Photoreal Hero: "The Night the Power Went Out"
```
A man in his thirties in a dark raincoat standing at the edge of a rainy street at night, holding a flashlight pointed down, face turned slightly toward the camera, positioned on the left third.
Background: a wet city street, out-of-focus streetlights forming soft amber orbs, deep navy sky.
Composition: medium wide, subject left, open dark space on the right for a single-word headline.
Colour palette: teal-and-navy shadows, warm amber practical lights, one cool rim highlight.
Lighting: amber street lamps as key, cool blue rim light from behind, rain catching the light.
Effects: subtle rain streaks, mild atmospheric haze, shallow depth of field.
Camera: low angle, 35mm feel, cinematic framing.
Rendering: photoreal, cinematic grade, fine skin detail.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```

### 4. Illustrative 3D Explainer: "How Small Shops Can Take Payments Online"
```
A stylised 3D character with simple friendly features, a small shop owner holding a phone with a floating payment card icon above it, standing in front of an open shopfront door, positioned on the right third.
Background: bright sky-blue gradient with soft cloud shapes, floating UI panels in cream and white on the left.
Composition: character right, empty left third for headline text.
Colour palette: sky blue base, burnt orange accent on the card icon and decorative burst shapes, cream panels, deep blue details.
Lighting: soft even studio light from the upper left, gentle shadows beneath the character.
Effects: small flat orange burst shapes and sparkles around the character.
Camera: slightly high three-quarter view, medium shot.
Rendering: clean 3D render, smooth surfaces, no photoreal textures.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```

### 5. Character Macro Action: "The Last Lantern Keeper"
```
A weathered traveller in a dark cloak and a bronze-plated shoulder guard, holding a glowing lantern near the chest, face partly lit from below, a small grey wolf companion pressed close at the lower left, positioned on the right third.
Background: foggy pine forest at dusk, deep slate tones, soft silhouettes of trees.
Composition: close-up on the traveller, wolf in the foreground at the lower left, open dark sky on the upper left for a headline.
Colour palette: slate blue base, ember orange lantern glow, pale gold rim light, small petal-pink accents in the mist.
Lighting: warm lantern key from below and front, cool blue ambient fill, sharp rim light from behind.
Effects: floating embers and drifting mist, mild motion blur on the embers.
Camera: low angle, 50mm feel, shallow depth of field.
Rendering: painterly digital art with clear detail on face and metal, cinematic.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```

### 6. Editorial Display Headline: "Why Most Side Projects Die in Week Two"
```
A woman in a navy blazer, arms loosely folded, calm and direct expression, seated on the right third of a plain off-white studio backdrop, light grey floor.
Background: seamless off-white paper backdrop with soft even gradient.
Composition: subject right, large negative space left for a headline that fills the frame height.
Colour palette: off-white base, navy and black subject, one small red accent on a sticker shape.
Lighting: large soft key from the front-left, gentle fill, minimal shadow on backdrop.
Camera: eye level, 85mm feel, medium shot.
Rendering: photoreal, clean editorial look, sharp focus.
Aspect ratio 16:9.
No text, no logos, no watermarks.
```
Add later: "DIES IN WEEK 2" in a tall high-contrast serif in black, left-aligned, with a small red circle badge.

## Common mistakes

| Mistake | Effect | Fix |
|---|---|---|
| Asking for text in the image | Misspelled or garbled words | Generate without text; add in editor |
| Naming a real person | Likeness and rights risk | Use generic descriptions |
| Naming a brand or logo | Trademark risk, inaccurate marks | Use a generic symbol or none |
| Too many colours named | Competing palette | Limit to base, accent, neutral |
| No negative space stated | Subject fills frame, no room for text | Name the empty third explicitly |
| Vague lighting ("nice lighting") | Random results | Name the direction and quality |
| Prompt over 150 words | Model ignores later details | Trim to the 11 slots |
| Copying a reference's wording | Derivative output | Describe the design principle, not the image |

## Iteration loop

1. Generate four variants from one prompt.
2. Pick the one with the clearest subject and negative space.
3. Change one slot at a time and regenerate.
4. Add text in the editor and check at 10 percent size.
5. Save the prompt that worked as a reusable template.
