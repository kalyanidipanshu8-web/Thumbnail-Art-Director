# Style Library

Styles were extracted from eight reference thumbnails and several channel-grid screenshots. Confidence is given per style. "Observed" means the trait is visible in several references. "Single-image" means it appears in one reference only.

---

## 1. Bold Overlay Tutorial
**Confidence: high.** Seen across most tutorial-style references.

- **Subject:** one person, medium close-up, facing camera or turned slightly, with an expressive face (focused, surprised, or confident).
- **Text:** one or two large words in all caps, placed in the empty side of the frame. Often a key phrase such as "MASTER AI REALISM" or "HOW I DID IT".
- **Annotation:** hand-drawn-style curved arrows pointing at the subject or the result, plus small callout text.
- **Palette:** black or dark background, white text, one saturated accent (yellow or red).
- **Use when:** teaching a process, promising a method, or showing a result.

## 2. Split-Screen Comparison
**Confidence: high.** Seen in the "Marvel / Mine" and "Day 1 / Day 10" style references.

- **Layout:** two equal panels side by side, divided by a hard vertical line.
- **Labels:** a short label block on each panel, often in a bold sans with a contrasting background (red, white).
- **Subject:** the same person or scene in both panels, so the difference reads at a glance.
- **Use when:** showing a before/after, an original versus a recreation, or a time-based change.

## 3. Cinematic Photoreal Hero
**Confidence: high.** Seen in the solo-filmmaking, Spider-Man-style, and realism references.

- **Subject:** a single person or character, photoreal or hyperreal, with skin texture and fine detail visible.
- **Lighting:** directional key light with a rim or edge light, a soft background falloff, and a shallow depth of field.
- **Colour:** a teal-and-warm or cool-blue-and-amber grade, with rich shadows.
- **Text:** minimal, often one short phrase, or none.
- **Use when:** the content is about quality, realism, cinematic output, or a dramatic reveal.

## 4. Editorial Display Headline
**Confidence: medium.** Seen in the "MILLION" and "Master viral trends" references.

- **Type:** very large, high-contrast serif or heavy condensed display type, sometimes filling the full width.
- **Layout:** the headline is the dominant element and the subject sits behind or beside it.
- **Palette:** off-white or pale background, black type, one accent colour in a small badge.
- **Use when:** the headline is a bold claim, a number, or a single-word hook.

## 5. Red Banner Presenter (Creator-Series)
**Confidence: high for the channel grids; medium for the palette rule.** Seen in the creator-channel screenshots.

- **Palette:** saturated red background or band, white and yellow display type, black or charcoal as a secondary colour.
- **Subject:** a presenter in the right third, looking at the viewer, often with one gesture (pointing, hand raised).
- **Text:** a large, tightly set headline on the left, with one keyword highlighted in yellow or in a white box.
- **Use when:** a talk, interview, or opinion video where the presenter's face drives recognition.

## 6. Illustrative 3D Explainer
**Confidence: medium.** Seen in the "Claude Motion" and "Claude Editing" style references, and the stylised animation references.

- **Subject:** a stylised or 3D-rendered figure with simplified features and bright, clean colours.
- **Decoration:** flat orange or coloured burst shapes, sparkles, and floating UI-like panels around the subject.
- **Text:** a short brand-style or display-serif phrase, placed on one side.
- **Use when:** the topic is abstract, software-based, or animated, and a photo would look too literal.

## 7. Character Macro Action
**Confidence: medium.** Seen in the armoured-character and animal-companion references.

- **Subject:** a character in close-up with an action or emotional beat (a sword raised, a companion animal close).
- **Lighting:** dramatic side light with particles, sparks, or petals adding depth.
- **Text:** one large phrase in a condensed display font with a dark outline.
- **Use when:** storytelling, fantasy, or a series with a recurring character.

## 8. Numbered Countdown
**Confidence: single-image.** Seen in one channel grid with numbered badges.

- **Layout:** a numbered badge in a corner (red or yellow) with a location or item name.
- **Subject:** a consistent presenter in the same framing across the series.
- **Use when:** a list, a ranking, or a series with numbered parts.

---

## Common palette family across styles

Most references share a small palette: one dark base (black, charcoal, deep navy), one light base (white, cream), one strong accent (red, yellow, or orange). Keep that family when adapting a style to a new topic.

## Differences that are not style

- Subject identity and clothing differ across references. These are content, not style.
- Specific brand marks, logos, and trademarked characters appear in some references. Never carry them into new work.
- Channel-grid screenshots show thumbnails at small size. Fine detail such as exact typeface, shadow depth, and precise colours is uncertain at that scale.
